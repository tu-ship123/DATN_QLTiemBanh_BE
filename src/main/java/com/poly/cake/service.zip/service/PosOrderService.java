package com.poly.cake.service;

import com.poly.cake.dto.PosOrderDto;
import com.poly.cake.entity.*;
import com.poly.cake.exception.BusinessException;
import com.poly.cake.exception.ResourceNotFoundException;
import com.poly.cake.repository.DonHangRepository;
import com.poly.cake.repository.ChiTietDonHangRepository;
import com.poly.cake.repository.NguoiDungRepository;
import com.poly.cake.repository.SanPhamRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import com.poly.cake.repository.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
@Slf4j
@Service
@RequiredArgsConstructor
public class PosOrderService {

    private final DonHangRepository donHangRepository;
    private final ChiTietDonHangRepository chiTietDonHangRepository;
    private final NguoiDungRepository nguoiDungRepository;
    private final SanPhamRepository sanPhamRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public PosOrderDto.Response createPosOrder(PosOrderDto.Request request, String emailNhanVien) {
        // 1. Xác định nhân viên đang đứng quầy (Dùng ResourceNotFoundException)
        NguoiDung nhanVien = nguoiDungRepository.findByEmail(emailNhanVien)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy thông tin nhân viên!"));

        // 2. Xác định khách hàng (Tự động lấy vãng lai nếu trống)
        NguoiDung khachHang;
        if (request.getEmailKhachHang() == null || request.getEmailKhachHang().isEmpty()) {
            khachHang = getOrCreateGuestAccount(); // Sử dụng hàm "tự chữa lành" đã làm ở bước trước
        } else {
            khachHang = nguoiDungRepository.findByEmail(request.getEmailKhachHang())
                    .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy tài khoản khách hàng: " + request.getEmailKhachHang()));
        }

        // 3. Validate giỏ hàng (Dùng BusinessException)
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new BusinessException("Hóa đơn phải có ít nhất 1 sản phẩm!");
        }

        // 3. Khởi tạo đơn hàng POS
        DonHang donHang = new DonHang();
        donHang.setKhachHang(khachHang);
        donHang.setNhanVien(nhanVien);
        donHang.setNguonDon("POS");
        donHang.setTrangThai(TrangThaiDonHang.HOAN_THANH);// Mua tại quầy thì mặc định xác nhận luôn
        donHang.setNgayTao(LocalDateTime.now());
        donHang.setGhiChu(request.getGhiChu());
        donHang.setTongTien(BigDecimal.ZERO); // Tạm thời gán bằng 0 để cộng dồn sau

        DonHang savedDonHang = donHangRepository.save(donHang);

        // 4. Duyệt danh sách món, cộng dồn tiền hàng, trừ tồn kho và lưu chi tiết
        BigDecimal totalAmount = BigDecimal.ZERO;
        List<ChiTietDonHang> chiTietList = new ArrayList<>();
        StringBuilder receiptItems = new StringBuilder(); // Dùng để build văn bản in hóa đơn

        for (PosOrderDto.ItemRequest item : request.getItems()) {
            SanPham sanPham = sanPhamRepository.findById(item.getSanPhamId())
                    .orElseThrow(() -> new RuntimeException("Sản phẩm mã " + item.getSanPhamId() + " không tồn tại!"));

            // [ĐÃ SỬA]: Chống Race Condition bằng Atomic Update trực tiếp dưới DB
            int updatedRows = sanPhamRepository.truSoLuongTon(item.getSanPhamId(), item.getSoLuong());

            if (updatedRows == 0) {
                throw new RuntimeException("Sản phẩm [" + sanPham.getTenSanPham() + "] không đủ số lượng trong kho lúc này!");
            }

            // Tính tiền món
            BigDecimal itemTotal = sanPham.getDonGia().multiply(BigDecimal.valueOf(item.getSoLuong()));
            totalAmount = totalAmount.add(itemTotal);

            // Tạo chi tiết đơn hàng
            ChiTietDonHang chiTiet = new ChiTietDonHang();
            chiTiet.setDonHang(savedDonHang);
            chiTiet.setSanPham(sanPham);
            chiTiet.setSoLuong(item.getSoLuong());
            chiTiet.setDonGiaTaiThoiDiem(sanPham.getDonGia());
            chiTietList.add(chiTiet);

            // Format dòng in hóa đơn: Tên bánh x Số lượng -> Thành tiền
            receiptItems.append(String.format("%-18s x%d   %s\n",
                    sanPham.getTenSanPham(), item.getSoLuong(), itemTotal.toString()));
        }

        chiTietDonHangRepository.saveAll(chiTietList);
        savedDonHang.setTongTien(totalAmount);
        donHangRepository.save(savedDonHang);

        // 5. TÍCH HỢP VIETQR (Bắn link ảnh QR động thông qua dịch vụ miễn phí của VietQR.io)
        String bankId = "vcb";
        String accountNo = "1234567890";
        String template = "qr_only";
        String addInfo = "PAY_POS_HD" + savedDonHang.getId();

        String vietQrUrl = String.format("https://img.vietqr.io/image/%s-%s-%s.png?amount=%s&addInfo=%s",
                bankId, accountNo, template, totalAmount.toBigInteger().toString(), addInfo);

        // 6. BUILD BIÊN LAI IN NHIỆT (Receipt) cho máy in tại quầy
        String receiptText = buildReceiptTemplate(savedDonHang, receiptItems.toString(), nhanVien.getHoTen());

        // 7. Map dữ liệu trả về cho Response DTO
        PosOrderDto.Response response = new PosOrderDto.Response();
        response.setDonHangId(savedDonHang.getId());
        response.setTongTien(totalAmount);
        response.setTrangThai(savedDonHang.getTrangThai().name());
        response.setNguonDon(savedDonHang.getNguonDon());
        response.setVietQrUrl(vietQrUrl);
        response.setReceiptText(receiptText);

        return response;
    }

    // Hàm phụ định dạng văn bản in hóa đơn cân đối
    private String buildReceiptTemplate(DonHang donHang, String itemsText, String tenNhanVien) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "======= TIỆM BÁNH POLY CAKE =======" + "\n" +
                "Đ/C: Toà nhà FPT Polytechnic, HCM" + "\n" +
                "HÓA ĐƠN BÁN HÀNG TẠI QUẦY" + "\n" +
                "-----------------------------------" + "\n" +
                "Mã HD: HD-POS-" + donHang.getId() + "\n" +
                "Ngày: " + LocalDateTime.now().format(formatter) + "\n" +
                "Thu ngân: " + tenNhanVien + "\n" +
                "-----------------------------------" + "\n" +
                itemsText +
                "-----------------------------------" + "\n" +
                "TỔNG TIỀN: " + donHang.getTongTien().toString() + " VND\n" +
                "===================================" + "\n" +
                "  CẢM ƠN QUÝ KHÁCH - HẸN GẶP LẠI!  " + "\n";
    }
    // Hàm này đảm bảo tài khoản khách vãng lai luôn có mặt trong DB
    private NguoiDung getOrCreateGuestAccount() {
        String guestEmail = "khachvanglai@gmail.com";
        return nguoiDungRepository.findByEmail(guestEmail)
                .orElseGet(() -> {
                    // Nếu chưa có, tự động tạo mới!
                    NguoiDung guest = new NguoiDung();
                    guest.setEmail(guestEmail);
                    guest.setHoTen("Khách Vãng Lai");
                    guest.setQuyen("KHACH_HANG");
                    guest.setTrangThai("HOAT_DONG");
                    guest.setMatKhau(passwordEncoder.encode("123456")); // Mật khẩu mặc định an toàn
                    log.info("Hệ thống tự động khởi tạo tài khoản khách vãng lai.");
                    return nguoiDungRepository.save(guest);
                });
    }
}