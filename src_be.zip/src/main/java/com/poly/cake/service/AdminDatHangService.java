package com.poly.cake.service;

import com.poly.cake.exception.NgoaiLeNghiepVu;
import com.poly.cake.exception.NgoaiLeKhongTimThayTaiNguyen;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.poly.cake.dto.DatHangDto;
import com.poly.cake.entity.*;
import com.poly.cake.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminDatHangService {

    private final DonHangRepository donHangRepository;
    private final NguoiDungRepository nguoiDungRepository;
    private final SanPhamRepository sanPhamRepository;
    private final ThongBaoService notificationService;
    private final PhuKienTrangTriRepository phuKienTrangTriRepository;

    // T080 – Refund: dùng để cập nhật trạng thái bản ghi thanh toán về DA_HOAN_TIEN
    private final ThanhToanRepository thanhToanRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // T080 – Barcode giao hàng: mã in trên bill có dạng "HD-{id}" (xem mapToResponseDto
    // / getPrintData -> maDonHang), tái sử dụng cùng quy ước regex với Webhook SePay.
    private static final Pattern DELIVERY_BARCODE_PATTERN = Pattern.compile("HD-?(\\d+)", Pattern.CASE_INSENSITIVE);

    // Dùng Enum thay vì String để đảm bảo Compile-time safety
    private static final List<TrangThaiDonHang> STATUS_FLOW = List.of(
            TrangThaiDonHang.CHO_XAC_NHAN, TrangThaiDonHang.DA_XAC_NHAN,
            TrangThaiDonHang.DANG_LAM, TrangThaiDonHang.SAN_SANG,
            TrangThaiDonHang.DANG_GIAO, TrangThaiDonHang.HOAN_THANH
    );

    // Dùng EnumSet để tối ưu hóa hiệu suất tìm kiếm
    // T080: DA_GIAO (đã quét mã giao hàng) cũng coi là kết thúc — tránh trường hợp
    // STATUS_FLOW.indexOf(DA_GIAO) = -1 khiến changeOrderStatus() hiểu nhầm là
    // "chưa ở đâu trong luồng" rồi lại cho phép đổi lùi/đổi tiếp sang trạng thái khác.
    private static final EnumSet<TrangThaiDonHang> TERMINAL_STATUSES = EnumSet.of(
            TrangThaiDonHang.HOAN_THANH, TrangThaiDonHang.DA_HUY,
            TrangThaiDonHang.DA_HOAN_TIEN, TrangThaiDonHang.DA_GIAO
    );

    public List<DatHangDto.Response> getFilteredOrders(String trangThai, String nguonDon, LocalDateTime tuNgay, LocalDateTime denNgay) {
        return donHangRepository.filterAdminOrders(trangThai, nguonDon, tuNgay, denNgay)
                .stream().map(this::mapToResponseDto).collect(Collectors.toList());
    }

    @Transactional
    public DatHangDto.Response overrideOrderStatus(Long id, String trangThaiMoi, String lyDo, String emailAdmin) {
        DonHang donHang = findOrder(id);
        NguoiDung admin = findAdmin(emailAdmin);

        TrangThaiDonHang trangThaiCu = donHang.getTrangThai();
        try {
            TrangThaiDonHang newStatus = TrangThaiDonHang.valueOf(trangThaiMoi.toUpperCase());
            donHang.setTrangThai(newStatus);
        } catch (IllegalArgumentException e) {
            throw new NgoaiLeNghiepVu("Trạng thái đơn hàng không hợp lệ: " + trangThaiMoi);
        }

        appendMiniAuditLog(donHang, admin.getHoTen(), "Ép đổi trạng thái từ " + trangThaiCu.name() + " sang " + trangThaiMoi + ". Lý do: " + lyDo);

        DonHang updatedDonHang = donHangRepository.save(donHang);
        notifyUser(updatedDonHang, "Đơn hàng HD-" + id + " của bạn đã được Admin xử lý: " + trangThaiMoi);

        return mapToResponseDto(updatedDonHang);
    }

    @Transactional
    public DatHangDto.Response refundOrder(Long id, String lyDo, String emailAdmin) {
        DonHang donHang = findOrder(id);
        NguoiDung admin = findAdmin(emailAdmin);

        if (lyDo == null || lyDo.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Bắt buộc phải nhập lý do hoàn tiền!");
        }
        if (donHang.getTrangThai() == TrangThaiDonHang.DA_HOAN_TIEN) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + id + " đã được hoàn tiền từ trước!");
        }
        if (donHang.getTrangThai() == TrangThaiDonHang.DA_HUY) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + id + " đã bị hủy, không thể hoàn tiền!");
        }

        // Ghi nhớ trạng thái trước khi hoàn tiền để biết đơn đã từng bị trừ tồn kho
        // hay chưa (chỉ các đơn đã qua CHO_XAC_NHAN trở đi mới đã trừ kho).
        TrangThaiDonHang trangThaiTruocKhiHoan = donHang.getTrangThai();

        donHang.setTrangThai(TrangThaiDonHang.DA_HOAN_TIEN);
        donHang.setLyDoHuy("Hoàn tiền: " + lyDo);

        // Đồng bộ bản ghi thanh toán (nếu có) về trạng thái đã hoàn tiền, để trang
        // đối soát doanh thu/thanh toán không bị lệch với trạng thái đơn hàng.
        thanhToanRepository.findByDonHang(donHang).ifPresent(tt -> {
            tt.setTrangThai("DA_HOAN_TIEN");
            thanhToanRepository.save(tt);
        });

        // Hoàn trả lại số lượng tồn kho cho từng sản phẩm trong đơn (nếu trước đó
        // đã bị trừ kho), tránh thất thoát tồn kho khi hoàn tiền cho khách.
        if (trangThaiTruocKhiHoan != TrangThaiDonHang.CHO_XAC_NHAN) {
            for (ChiTietDonHang ct : donHang.getChiTietDonHangs()) {
                sanPhamRepository.congLaiSoLuongTon(ct.getSanPham().getId(), ct.getSoLuong());
            }
        }

        appendMiniAuditLog(donHang, admin.getHoTen(), "Hoàn tiền cho khách. Lý do: " + lyDo);

        DonHang updatedDonHang = donHangRepository.save(donHang);
        notifyUser(updatedDonHang, "Đơn hàng HD-" + id + " đã được hoàn tiền thành công. Lý do: " + lyDo);

        return mapToResponseDto(updatedDonHang);
    }

    @Transactional
    public void cancelAndRollbackInventory(Long id, String lyDo, String emailAdmin) {
        DonHang donHang = findOrder(id);
        NguoiDung admin = findAdmin(emailAdmin);

        if (donHang.getTrangThai() == TrangThaiDonHang.DA_HUY) {
            throw new NgoaiLeNghiepVu("Đơn hàng này đã bị hủy từ trước!");
        }

        donHang.setTrangThai(TrangThaiDonHang.DA_HUY);
        donHang.setLyDoHuy("Admin Hủy & Rollback kho: " + lyDo);
        appendMiniAuditLog(donHang, admin.getHoTen(), "Hủy đơn ép buộc & Hoàn số lượng về kho. Lý do: " + lyDo);

        DonHang updatedDonHang = donHangRepository.save(donHang);

        for (ChiTietDonHang ct : updatedDonHang.getChiTietDonHangs()) {
            sanPhamRepository.congLaiSoLuongTon(ct.getSanPham().getId(), ct.getSoLuong());
        }
        notifyUser(updatedDonHang, "Đơn hàng HD-" + id + " đã bị hủy bởi hệ thống. Lý do: " + lyDo);
    }

    @Transactional
    public DatHangDto.Response updateOrderInfo(Long id, DatHangDto.UpdateRequest request, String emailAdmin) {
        DonHang donHang = findOrder(id);
        NguoiDung admin = findAdmin(emailAdmin);

        if (TERMINAL_STATUSES.contains(donHang.getTrangThai())) {
            throw new NgoaiLeNghiepVu("Không thể chỉnh sửa đơn hàng ở trạng thái: " + donHang.getTrangThai().name());
        }

        StringBuilder changes = new StringBuilder("Chỉnh sửa thông tin đơn:");
        boolean hasChange = false;

        if (request.getDiaChiGiaoHang() != null) {
            changes.append(" Địa chỉ=[").append(request.getDiaChiGiaoHang()).append("]");
            donHang.setDiaChiGiao(request.getDiaChiGiaoHang());
            hasChange = true;
        }
        if (request.getSoDienThoai() != null && donHang.getKhachHang() != null) {
            changes.append(" SĐT=[").append(request.getSoDienThoai()).append("]");
            donHang.getKhachHang().setSoDienThoai(request.getSoDienThoai());
            nguoiDungRepository.save(donHang.getKhachHang());
            hasChange = true;
        }
        if (request.getNgayGiaoHang() != null) {
            changes.append(" NgàyGiao=[").append(request.getNgayGiaoHang()).append("]");
            donHang.setNgayGiaoDuKien(request.getNgayGiaoHang().atStartOfDay());
            hasChange = true;
        }
        if (request.getGhiChu() != null) {
            String auditPart = extractAuditLog(donHang.getGhiChu());
            donHang.setGhiChu(request.getGhiChu() + (auditPart.isEmpty() ? "" : "\n" + auditPart));
            changes.append(" GhiChú=[đã cập nhật]");
            hasChange = true;
        }

        if (!hasChange) {
            throw new NgoaiLeNghiepVu("Không có thông tin nào được thay đổi!");
        }

        appendMiniAuditLog(donHang, admin.getHoTen(), changes.toString());
        DonHang saved = donHangRepository.save(donHang);
        return mapToResponseDto(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // T080 – GHI CHÚ NỘI BỘ
    // Nhân viên thêm ghi chú nội bộ → Bếp thấy (qua danh sách/chi tiết đơn hàng
    // trong trang quản trị), khách hàng KHÔNG bao giờ thấy vì đây là cột riêng
    // (ghi_chu_noi_bo), tách biệt hoàn toàn khỏi "ghiChu" công khai và không được
    // set trong DatHangDto.Response ở phía DatHangService (API khách hàng dùng).
    // ─────────────────────────────────────────────────────────────────────────
    @Transactional
    public DatHangDto.Response updateInternalNote(Long id, String ghiChuNoiBo, String emailNhanVien) {
        DonHang donHang = findOrder(id);
        NguoiDung nhanVien = findAdmin(emailNhanVien);

        if (ghiChuNoiBo == null || ghiChuNoiBo.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Nội dung ghi chú nội bộ không được để trống!");
        }

        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        String noteLine = String.format("[%s - %s]: %s", time, nhanVien.getHoTen(), ghiChuNoiBo.trim());
        String currentNote = (donHang.getGhiChuNoiBo() == null) ? "" : donHang.getGhiChuNoiBo() + "\n";
        donHang.setGhiChuNoiBo(currentNote + noteLine);

        DonHang saved = donHangRepository.save(donHang);
        return mapToResponseDto(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // T080 – BARCODE GIAO HÀNG
    // Nhân viên giao hàng quét mã trên bill (dạng "HD-{id}") lúc giao tận nơi
    // cho khách → hệ thống tự động chuyển đơn từ DANG_GIAO sang DA_GIAO, ghi
    // nhận thời điểm giao thực tế + báo khách, KHÔNG cần thao tác đổi trạng thái
    // thủ công qua màn hình quản trị.
    // ─────────────────────────────────────────────────────────────────────────
    @Transactional
    public DatHangDto.Response scanDelivery(String maVach, String emailNhanVien) {
        NguoiDung nhanVien = findAdmin(emailNhanVien);

        if (maVach == null || maVach.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Vui lòng quét/nhập mã đơn hàng cần giao!");
        }

        Matcher matcher = DELIVERY_BARCODE_PATTERN.matcher(maVach.trim());
        if (!matcher.find()) {
            throw new NgoaiLeNghiepVu("Mã vạch không hợp lệ! Không tìm thấy mã đơn hàng trong: " + maVach);
        }
        Long orderId = Long.parseLong(matcher.group(1));

        DonHang donHang = findOrder(orderId);

        if (donHang.getTrangThai() == TrangThaiDonHang.DA_GIAO) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + orderId + " đã được quét giao hàng trước đó rồi!");
        }
        if (donHang.getTrangThai() != TrangThaiDonHang.DANG_GIAO) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + orderId + " đang ở trạng thái "
                    + donHang.getTrangThai().name() + ", chỉ có thể quét giao khi đơn đang ở trạng thái DANG_GIAO!");
        }

        LocalDateTime thoiDiemGiao = LocalDateTime.now();
        donHang.setTrangThai(TrangThaiDonHang.DA_GIAO);
        donHang.setThoiDiemGiao(thoiDiemGiao);
        donHang.setNhanVien(nhanVien);

        appendMiniAuditLog(donHang, nhanVien.getHoTen(),
                "Quét mã vạch giao hàng thành công → chuyển sang DA_GIAO.");

        // FIX: đơn COD (thanh toán tiền mặt khi nhận hàng) được tạo với ThanhToan ở
        // trạng thái CHO_THANH_TOAN (xem DatHangService.createOrder()). Trước đây
        // không có bước nào cập nhật bản ghi này khi khách đã thực nhận và trả tiền,
        // khiến các đơn COD KHÔNG BAO GIỜ được tính vào đối soát/kết ca dù đã thu tiền
        // thành công. Nay khi shipper quét mã xác nhận đã giao (và đơn là tiền mặt),
        // đánh dấu luôn ThanhToan = THANH_CONG.
        thanhToanRepository.findByDonHang(donHang).ifPresent(tt -> {
            if ("TIEN_MAT".equalsIgnoreCase(tt.getHinhThuc()) && !"THANH_CONG".equals(tt.getTrangThai())) {
                tt.setTrangThai("THANH_CONG");
                tt.setThoiDiemThanhToan(thoiDiemGiao);
                thanhToanRepository.save(tt);
            }
        });

        DonHang saved = donHangRepository.save(donHang);
        notifyUser(saved, "📦 Đơn hàng HD-" + orderId + " của bạn đã được giao thành công lúc "
                + thoiDiemGiao.format(DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy")) + "!");

        return mapToResponseDto(saved);
    }

    @Transactional
    public DatHangDto.Response changeOrderStatus(Long id, String trangThaiMoi, String lyDoHuy, String emailAdmin) {
        DonHang donHang = findOrder(id);
        NguoiDung admin = findAdmin(emailAdmin);

        TrangThaiDonHang trangThaiHienTai = donHang.getTrangThai();
        TrangThaiDonHang newStatus;

        try {
            newStatus = TrangThaiDonHang.valueOf(trangThaiMoi.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new NgoaiLeNghiepVu("Trạng thái '" + trangThaiMoi + "' không hợp lệ!");
        }

        if (TERMINAL_STATUSES.contains(trangThaiHienTai)) {
            throw new NgoaiLeNghiepVu("Đơn hàng đã kết thúc, không thể đổi trạng thái!");
        }

        if (newStatus != TrangThaiDonHang.DA_HUY) {
            int currentIdx = STATUS_FLOW.indexOf(trangThaiHienTai);
            int newIdx     = STATUS_FLOW.indexOf(newStatus);
            if (newIdx < 0) {
                throw new NgoaiLeNghiepVu("Trạng thái không nằm trong luồng chuẩn!");
            }
            if (newIdx <= currentIdx) {
                throw new NgoaiLeNghiepVu("Không thể lùi trạng thái! Hiện tại: " + trangThaiHienTai.name());
            }
        } else {
            if (lyDoHuy == null || lyDoHuy.trim().isEmpty()) {
                throw new NgoaiLeNghiepVu("Bắt buộc phải nhập lý do khi hủy đơn hàng!");
            }
            donHang.setLyDoHuy(lyDoHuy);
        }

        donHang.setTrangThai(newStatus);
        donHang.setNhanVien(admin);
        appendMiniAuditLog(donHang, admin.getHoTen(), "Đổi trạng thái → " + newStatus.name());

        DonHang saved = donHangRepository.save(donHang);
        notifyUser(saved, "Đơn hàng HD-" + id + " của bạn vừa chuyển sang: " + newStatus.name());

        return mapToResponseDto(saved);
    }

    public DatHangDto.PrintResponse getPrintData(Long id) {
        DonHang donHang = findOrder(id);

        DatHangDto.PrintResponse print = new DatHangDto.PrintResponse();
        print.setId(donHang.getId());
        print.setMaDonHang("HD-" + donHang.getId());
        print.setTrangThai(donHang.getTrangThai().name());
        print.setNgayTao(donHang.getNgayTao());
        print.setNguonDon(donHang.getNguonDon());

        if (donHang.getNgayGiaoDuKien() != null) {
            print.setNgayGiaoHang(donHang.getNgayGiaoDuKien().toLocalDate());
        }

        double tongTien  = donHang.getTongTien()  != null ? donHang.getTongTien().doubleValue()  : 0.0;
        double soTienCoc = donHang.getSoTienCoc() != null ? donHang.getSoTienCoc().doubleValue() : 0.0;
        print.setTongTien(tongTien);
        print.setSoTienCoc(soTienCoc);
        print.setConLai(tongTien - soTienCoc);
        print.setGhiChu(extractUserNote(donHang.getGhiChu()));
        print.setGhiChuNoiBo(donHang.getGhiChuNoiBo());

        if (donHang.getKhachHang() != null) {
            NguoiDung kh = donHang.getKhachHang();
            print.setTenKhachHang(kh.getHoTen());
            print.setEmailKhachHang(kh.getEmail());
            print.setSdtKhachHang(kh.getSoDienThoai());
        }
        print.setDiaChiGiaoHang(donHang.getDiaChiGiao());

        if (donHang.getNhanVien() != null) {
            print.setTenNhanVien(donHang.getNhanVien().getHoTen());
        }

        if (donHang.getChiTietDonHangs() != null) {
            List<DatHangDto.PrintResponse.PrintItem> items = donHang.getChiTietDonHangs()
                    .stream().map(ct -> {
                        DatHangDto.PrintResponse.PrintItem item = new DatHangDto.PrintResponse.PrintItem();
                        item.setTenSanPham(ct.getSanPham().getTenSanPham());
                        item.setSoLuong(ct.getSoLuong());
                        double donGia = ct.getDonGiaTaiThoiDiem() != null
                                ? ct.getDonGiaTaiThoiDiem().doubleValue() : 0.0;
                        item.setDonGia(donGia);
                        item.setThanhTien(donGia * ct.getSoLuong());
                        return item;
                    }).collect(Collectors.toList());
            print.setItems(items);
        }

        return print;
    }

    @Transactional
    public DatHangDto.Response createOrder(DatHangDto.Request request, String emailNhanVien) {
        NguoiDung nhanVien = nguoiDungRepository.findByEmail(emailNhanVien)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Lỗi xác thực Nhân viên/Admin"));

        DonHang donHang = new DonHang();
        donHang.setDiaChiGiao(request.getDiaChiGiaoHang());

        if (request.getNgayGiaoHang() != null) {
            donHang.setNgayGiaoDuKien(request.getNgayGiaoHang().atStartOfDay());
        }

        donHang.setGhiChu(request.getGhiChu() != null ? request.getGhiChu() : "");
        donHang.setNgayTao(LocalDateTime.now());
        donHang.setTrangThai(TrangThaiDonHang.DA_XAC_NHAN);
        donHang.setNhanVien(nhanVien);

        NguoiDung khachVangLai = nguoiDungRepository.findByEmail("khachvanglai@gmail.com")
                .orElseThrow(() -> new NgoaiLeNghiepVu("Lỗi: Trong Database chưa có user khachvanglai@gmail.com. Vui lòng tạo tài khoản này trước!"));
        donHang.setKhachHang(khachVangLai);

        if (request.getSoDienThoai() != null && !request.getSoDienThoai().isEmpty()) {
            donHang.setGhiChu(donHang.getGhiChu() + " | SĐT Khách: " + request.getSoDienThoai());
        }

        BigDecimal tongTien = BigDecimal.ZERO;
        List<ChiTietDonHang> chiTietList = new ArrayList<>();

        if (request.getItems() != null) {
            for (DatHangDto.OrderItemRequest itemReq : request.getItems()) {
                SanPham sanPham = sanPhamRepository.findById(itemReq.getSanPhamId())
                        .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy sản phẩm ID: " + itemReq.getSanPhamId()));

                if (sanPham.getSoLuongTon() < itemReq.getSoLuong()) {
                    throw new NgoaiLeNghiepVu("Sản phẩm '" + sanPham.getTenSanPham() + "' không đủ số lượng tồn kho!");
                }

                sanPham.setSoLuongTon(sanPham.getSoLuongTon() - itemReq.getSoLuong());
                sanPhamRepository.save(sanPham);

                ChiTietDonHang chiTiet = new ChiTietDonHang();
                chiTiet.setDonHang(donHang);
                chiTiet.setSanPham(sanPham);
                chiTiet.setSoLuong(itemReq.getSoLuong());

                BigDecimal donGia = BigDecimal.valueOf(itemReq.getDonGia());
                chiTiet.setDonGiaTaiThoiDiem(donGia);

                chiTietList.add(chiTiet);

                tongTien = tongTien.add(donGia.multiply(BigDecimal.valueOf(itemReq.getSoLuong())));
            }
        }

        donHang.setTongTien(tongTien);
        donHang.setChiTietDonHangs(chiTietList);

        appendMiniAuditLog(donHang, nhanVien.getHoTen(), "Khởi tạo đơn hàng mới từ hệ thống Admin.");

        DonHang savedDonHang = donHangRepository.save(donHang);
        return mapToResponseDto(savedDonHang);
    }

    @Transactional
    public DatHangDto.Response confirmDesign(Long orderId, String emailNhanVien) {
        DonHang donHang = findOrder(orderId);
        NguoiDung nhanVien = nguoiDungRepository.findByEmail(emailNhanVien)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy thông tin nhân viên!"));

        String designJson = donHang.getThietKeBanhJson();
        if (designJson == null || designJson.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + orderId + " không có thiết kế bánh 3D để xác nhận!");
        }

        if (donHang.getTrangThai() != TrangThaiDonHang.DA_XAC_NHAN) {
            throw new NgoaiLeNghiepVu("Chỉ có thể xác nhận thiết kế khi đơn ở trạng thái DA_XAC_NHAN!");
        }

        List<Map<String, Object>> danhSachPhuKien = parsePhuKienFromDesign(designJson, orderId);

        Map<Long, PhuKienTrangTri> phuKienCache = new java.util.LinkedHashMap<>();
        Map<Long, Integer> soLuongCanTru = new java.util.LinkedHashMap<>();

        for (Map<String, Object> pk : danhSachPhuKien) {
            Long phuKienId = toLong(pk.get("phu_kien_id"), "phu_kien_id");
            int soLuongCan = toInt(pk.get("so_luong"), "so_luong");

            PhuKienTrangTri phuKien = phuKienTrangTriRepository.findById(phuKienId)
                    .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Phụ kiện trang trí ID=" + phuKienId + " không tồn tại!"));

            if (!phuKien.getHoatDong()) {
                throw new NgoaiLeNghiepVu("Phụ kiện '" + phuKien.getTenPhuKien() + "' đã ngừng kinh doanh!");
            }

            if (phuKien.getSoLuongTon() < soLuongCan) {
                throw new NgoaiLeNghiepVu("Phụ kiện '" + phuKien.getTenPhuKien() + "' không đủ tồn kho!");
            }

            phuKienCache.put(phuKienId, phuKien);
            soLuongCanTru.put(phuKienId, soLuongCan);
        }

        StringBuilder dsPhuKienLog = new StringBuilder();
        for (Map.Entry<Long, PhuKienTrangTri> entry : phuKienCache.entrySet()) {
            PhuKienTrangTri phuKien = entry.getValue();
            int soLuongCan = soLuongCanTru.get(entry.getKey());

            phuKien.setSoLuongTon(phuKien.getSoLuongTon() - soLuongCan);
            phuKienTrangTriRepository.save(phuKien);

            dsPhuKienLog.append(phuKien.getTenPhuKien()).append(" x").append(soLuongCan).append(", ");
        }

        donHang.setTrangThai(TrangThaiDonHang.DANG_LAM);
        donHang.setNhanVien(nhanVien);

        String logContent = "Xác nhận thiết kế 3D → chuyển sang DANG_LAM.";
        if (!danhSachPhuKien.isEmpty()) {
            String dsPk = dsPhuKienLog.toString();
            logContent += " Đã trừ kho phụ kiện: " + dsPk.substring(0, dsPk.length() - 2) + ".";
        }
        appendMiniAuditLog(donHang, nhanVien.getHoTen(), logContent);

        DonHang saved = donHangRepository.save(donHang);
        notifyUser(saved, "🎂 Đơn hàng HD-" + orderId + " của bạn đã được xác nhận thiết kế và đang được làm bánh!");

        return mapToResponseDto(saved);
    }

    @Transactional
    public DatHangDto.Response rejectDesign(Long orderId, String lyDo, String emailNhanVien) {
        DonHang donHang = findOrder(orderId);
        NguoiDung nhanVien = nguoiDungRepository.findByEmail(emailNhanVien)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy thông tin nhân viên!"));

        if (lyDo == null || lyDo.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Bắt buộc phải nhập lý do từ chối thiết kế!");
        }

        String designJson = donHang.getThietKeBanhJson();
        if (designJson == null || designJson.trim().isEmpty()) {
            throw new NgoaiLeNghiepVu("Đơn hàng HD-" + orderId + " không có thiết kế bánh 3D để từ chối!");
        }

        if (donHang.getTrangThai() != TrangThaiDonHang.DA_XAC_NHAN) {
            throw new NgoaiLeNghiepVu("Chỉ có thể từ chối thiết kế khi đơn ở trạng thái DA_XAC_NHAN!");
        }

        donHang.setTrangThai(TrangThaiDonHang.CHO_XAC_NHAN);
        donHang.setNhanVien(nhanVien);
        donHang.setLyDoHuy("Từ chối thiết kế: " + lyDo.trim());

        appendMiniAuditLog(donHang, nhanVien.getHoTen(), "Từ chối thiết kế 3D → quay về CHO_XAC_NHAN. Lý do: " + lyDo.trim());

        DonHang saved = donHangRepository.save(donHang);
        notifyUser(saved, "⚠️ Đơn hàng HD-" + orderId + " – Thiết kế bánh chưa được duyệt. Lý do: " + lyDo.trim());

        return mapToResponseDto(saved);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parsePhuKienFromDesign(String designJson, Long orderId) {
        try {
            Map<String, Object> designMap = objectMapper.readValue(designJson, new TypeReference<Map<String, Object>>() {});
            Object trangTriObj = designMap.get("trang_tri");
            if (trangTriObj == null) return new ArrayList<>();
            if (!(trangTriObj instanceof List)) throw new NgoaiLeNghiepVu("Trường 'trang_tri' phải là mảng!");

            List<Object> rawList = (List<Object>) trangTriObj;
            List<Map<String, Object>> result = new ArrayList<>();

            for (Object item : rawList) {
                if (!(item instanceof Map)) continue;
                Map<String, Object> pkMap = (Map<String, Object>) item;
                if (pkMap.get("phu_kien_id") == null) continue;
                if (pkMap.get("so_luong") == null) {
                    pkMap = new java.util.HashMap<>(pkMap);
                    pkMap.put("so_luong", 1);
                }
                result.add(pkMap);
            }
            return result;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new NgoaiLeNghiepVu("Lỗi khi đọc dữ liệu thiết kế 3D của đơn HD-" + orderId + ": " + e.getMessage());
        }
    }

    private DonHang findOrder(Long id) {
        return donHangRepository.findById(id).orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy đơn hàng #" + id));
    }

    private NguoiDung findAdmin(String email) {
        return nguoiDungRepository.findByEmail(email).orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Lỗi xác thực Admin"));
    }

    private void appendMiniAuditLog(DonHang donHang, String tenNhanVien, String action) {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        String logLine = String.format("\n[AUDIT %s - %s]: %s", time, tenNhanVien, action);
        String currentNote = (donHang.getGhiChu() == null) ? "" : donHang.getGhiChu();
        donHang.setGhiChu(currentNote + logLine);
    }

    private String extractUserNote(String ghiChu) {
        if (ghiChu == null) return "";
        int auditIdx = ghiChu.indexOf("\n[AUDIT");
        return auditIdx >= 0 ? ghiChu.substring(0, auditIdx).trim() : ghiChu.trim();
    }

    private String extractAuditLog(String ghiChu) {
        if (ghiChu == null) return "";
        int auditIdx = ghiChu.indexOf("\n[AUDIT");
        return auditIdx >= 0 ? ghiChu.substring(auditIdx).trim() : "";
    }

    private void notifyUser(DonHang donHang, String message) {
        if (donHang.getKhachHang() != null && !"khachvanglai@gmail.com".equals(donHang.getKhachHang().getEmail())) {
            notificationService.notifyOrderStatusToUser(donHang.getKhachHang().getEmail(), message);
        }
    }

    private Long toLong(Object value, String fieldName) {
        if (value instanceof Number) return ((Number) value).longValue();
        try { return Long.parseLong(value.toString()); }
        catch (Exception e) { throw new NgoaiLeNghiepVu("Trường '" + fieldName + "' phải là số nguyên!"); }
    }

    private int toInt(Object value, String fieldName) {
        if (value instanceof Number) return ((Number) value).intValue();
        try { return Integer.parseInt(value.toString()); }
        catch (Exception e) { throw new NgoaiLeNghiepVu("Trường '" + fieldName + "' phải là số nguyên!"); }
    }

    private DatHangDto.Response mapToResponseDto(DonHang donHang) {
        DatHangDto.Response dto = new DatHangDto.Response();
        dto.setId(donHang.getId());
        dto.setMaDonHang("HD-" + donHang.getId());
        dto.setDiaChiGiaoHang(donHang.getDiaChiGiao());
        if (donHang.getKhachHang() != null) {
            dto.setSoDienThoai(donHang.getKhachHang().getSoDienThoai());
            dto.setEmailNguoiDung(donHang.getKhachHang().getEmail());
        }
        if (donHang.getNgayGiaoDuKien() != null) dto.setNgayGiaoHang(donHang.getNgayGiaoDuKien().toLocalDate());
        dto.setNgayTao(donHang.getNgayTao());
        if (donHang.getTongTien() != null) dto.setTongTien(donHang.getTongTien().doubleValue());

        // Trả về tên Enum (String) cho Frontend
        dto.setTrangThai(donHang.getTrangThai().name());

        dto.setGhiChu(donHang.getGhiChu());
        dto.setGhiChuNoiBo(donHang.getGhiChuNoiBo());
        dto.setLyDoHuy(donHang.getLyDoHuy());
        if (donHang.getNhanVien() != null) dto.setTenNhanVienPhuTrach(donHang.getNhanVien().getHoTen());
        dto.setCoThietKe3D(donHang.getThietKeBanhJson() != null && !donHang.getThietKeBanhJson().trim().isEmpty());

        if (donHang.getChiTietDonHangs() != null) {
            List<DatHangDto.OrderItemResponse> itemDtos = donHang.getChiTietDonHangs().stream().map(item -> {
                DatHangDto.OrderItemResponse itemDto = new DatHangDto.OrderItemResponse();
                itemDto.setSanPhamId(item.getSanPham().getId());
                itemDto.setTenSanPham(item.getSanPham().getTenSanPham());
                itemDto.setSoLuong(item.getSoLuong());
                itemDto.setGiaBan(item.getDonGiaTaiThoiDiem() != null ? item.getDonGiaTaiThoiDiem().doubleValue() : 0.0);
                return itemDto;
            }).collect(Collectors.toList());
            dto.setItems(itemDtos);
        }
        return dto;
    }
}