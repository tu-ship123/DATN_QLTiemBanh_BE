package com.poly.cake.service;

import com.poly.cake.exception.NgoaiLeNghiepVu;
import com.poly.cake.exception.NgoaiLeKhongTimThayTaiNguyen;

import com.poly.cake.dto.PosDatHangDto;
import com.poly.cake.entity.DonHang;
import com.poly.cake.entity.ChiTietDonHang;
import com.poly.cake.entity.MaGiamGia;
import com.poly.cake.entity.NguoiDung;
import com.poly.cake.entity.SanPham;
import com.poly.cake.entity.TrangThaiDonHang; // Đã thêm import Enum
import com.poly.cake.repository.DonHangRepository;
import com.poly.cake.repository.ChiTietDonHangRepository;
import com.poly.cake.repository.MaGiamGiaRepository;
import com.poly.cake.repository.NguoiDungRepository;
import com.poly.cake.repository.SanPhamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PosDatHangService {

    private final DonHangRepository donHangRepository;
    private final ChiTietDonHangRepository chiTietDonHangRepository;
    private final NguoiDungRepository nguoiDungRepository;
    private final SanPhamRepository sanPhamRepository;
    private final MaGiamGiaRepository maGiamGiaRepository;
    // T102 – Tính % phụ thu tự động theo ngày (đơn POS mua ngay nên tính theo ngày hôm nay)
    private final PhuThuDonHangService phuThuDonHangService;

    @Transactional
    public PosDatHangDto.Response createPosOrder(PosDatHangDto.Request request, String emailNhanVien) {
        // 1. Xác định nhân viên đang đứng quầy chốt đơn
        NguoiDung nhanVien = nguoiDungRepository.findByEmail(emailNhanVien)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy thông tin nhân viên!"));

        // 2. Xác định khách hàng (Nếu trống thì dùng email của nhân viên đang xử lý đơn)
        String emailKhach = (request.getEmailKhachHang() == null || request.getEmailKhachHang().isBlank())
                ? emailNhanVien : request.getEmailKhachHang();

        NguoiDung khachHang = nguoiDungRepository.findByEmail(emailKhach)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy tài khoản khách hàng với email: " + emailKhach));

        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new NgoaiLeNghiepVu("Hóa đơn phải có ít nhất 1 sản phẩm!");
        }

        // 3. Khởi tạo đơn hàng POS
        DonHang donHang = new DonHang();
        donHang.setKhachHang(khachHang);
        donHang.setNhanVien(nhanVien);
        donHang.setNguonDon("POS");

        // Mua tại quầy (POS) không đi qua luồng sản xuất/giao hàng như đơn online:
        // - Trả tiền mặt ngay tại quầy -> coi như hoàn tất giao dịch luôn.
        // - Trả qua QR -> tạm để DA_XAC_NHAN, chờ nhân viên xác nhận đã nhận tiền (API confirm-paid) mới chuyển HOAN_THANH.
        boolean laTienMat = !"VIET_QR".equalsIgnoreCase(request.getPhuongThucThanhToan());
        donHang.setTrangThai(laTienMat ? TrangThaiDonHang.HOAN_THANH : TrangThaiDonHang.DA_XAC_NHAN);

        donHang.setNgayTao(LocalDateTime.now());
        donHang.setGhiChu(request.getGhiChu());
        donHang.setTongTien(BigDecimal.ZERO); // Tạm thời gán bằng 0 để cộng dồn sau

        DonHang savedDonHang = donHangRepository.save(donHang);

        // 4. Duyệt danh sách món, cộng dồn tiền hàng, trừ tồn kho và lưu chi tiết
        BigDecimal totalAmount = BigDecimal.ZERO;
        List<ChiTietDonHang> chiTietList = new ArrayList<>();
        StringBuilder receiptItems = new StringBuilder(); // Dùng để build văn bản in hóa đơn

        for (PosDatHangDto.ItemRequest item : request.getItems()) {
            SanPham sanPham = sanPhamRepository.findById(item.getSanPhamId())
                    .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Sản phẩm mã " + item.getSanPhamId() + " không tồn tại!"));

            // Chống Race Condition bằng Atomic Update trực tiếp dưới DB
            int updatedRows = sanPhamRepository.truSoLuongTon(item.getSanPhamId(), item.getSoLuong());

            if (updatedRows == 0) {
                throw new NgoaiLeNghiepVu("Sản phẩm [" + sanPham.getTenSanPham() + "] không đủ số lượng trong kho lúc này!");
            }

            // Tính tiền món
            BigDecimal itemTotal = sanPham.getDonGia().multiply(BigDecimal.valueOf(item.getSoLuong()));
            totalAmount = totalAmount.add(itemTotal);

            // Tạo chi tiết đơn hàng
            ChiTietDonHang chiTiet = new ChiTietDonHang();
            chiTiet.setDonHang(savedDonHang);
            chiTiet.setSanPham(sanPham);
            chiTiet.setSoLuong(item.getSoLuong());
            chiTiet.setDonGiaTaiThoiDiem(sanPham.getDonGia());
            chiTietList.add(chiTiet);

            // Format dòng in hóa đơn: Tên bánh x Số lượng -> Thành tiền
            receiptItems.append(String.format("%-18s x%d   %s\n",
                    sanPham.getTenSanPham(), item.getSoLuong(), itemTotal.toString()));
        }

        chiTietDonHangRepository.saveAll(chiTietList);

        BigDecimal tienHangGoc = totalAmount; // Tiền hàng gốc, dùng để kiểm tra điều kiện mã & tính phụ thu

        // 4b. Áp mã giảm giá công khai nếu nhân viên có nhập (không bắt buộc)
        MaGiamGia maGiamGiaApDung = null;
        BigDecimal soTienGiam = BigDecimal.ZERO;
        String maCodeNhap = request.getMaGiamGia();

        if (maCodeNhap != null && !maCodeNhap.isBlank()) {
            maGiamGiaApDung = maGiamGiaRepository.findByMaCode(maCodeNhap.trim().toUpperCase())
                    .orElseThrow(() -> new NgoaiLeNghiepVu("Mã giảm giá \"" + maCodeNhap + "\" không tồn tại!"));

            kiemTraMaGiamGiaHopLe(maGiamGiaApDung, tienHangGoc);
            soTienGiam = tinhSoTienGiam(maGiamGiaApDung, tienHangGoc);

            totalAmount = totalAmount.subtract(soTienGiam);
            savedDonHang.setMaGiamGia(maGiamGiaApDung);
        }

        // T102 – Tự động cộng phụ thu nếu hôm nay rơi vào dịp đặc biệt đã cấu hình
        // (tính trên tiền hàng GỐC, trước khi trừ giảm giá — nhất quán với đơn ONLINE)
        BigDecimal phanTramPhuThu = phuThuDonHangService.tinhPhanTramPhuThu(java.time.LocalDate.now());
        BigDecimal soTienPhuThu = tienHangGoc
                .multiply(phanTramPhuThu)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        totalAmount = totalAmount.add(soTienPhuThu);

        savedDonHang.setSoTienPhuThu(soTienPhuThu);
        savedDonHang.setTongTien(totalAmount);
        donHangRepository.save(savedDonHang);

        // 4c. Nếu áp mã thành công thì cộng lượt đã dùng (chỉ commit sau khi đơn đã lưu thành công)
        if (maGiamGiaApDung != null) {
            maGiamGiaApDung.setSoLuotDaDung(
                    (maGiamGiaApDung.getSoLuotDaDung() == null ? 0 : maGiamGiaApDung.getSoLuotDaDung()) + 1);
            maGiamGiaRepository.save(maGiamGiaApDung);
        }

        // 5. TÍCH HỢP VIETQR (Bắn link ảnh QR động thông qua dịch vụ miễn phí của VietQR.io)
        String bankId = "vcb";
        String accountNo = "1234567890";
        String template = "qr_only";
        String addInfo = "PAY_POS_HD" + savedDonHang.getId();

        String vietQrUrl = String.format("https://img.vietqr.io/image/%s-%s-%s.png?amount=%s&addInfo=%s",
                bankId, accountNo, template, totalAmount.toBigInteger().toString(), addInfo);

        // 6. BUILD BIÊN LAI IN NHIỆT (Receipt) cho máy in tại quầy
        String receiptText = buildReceiptTemplate(savedDonHang, receiptItems.toString(), nhanVien.getHoTen(), soTienGiam, maGiamGiaApDung);

        // 7. Map dữ liệu trả về cho Response DTO
        PosDatHangDto.Response response = new PosDatHangDto.Response();
        response.setDonHangId(savedDonHang.getId());
        response.setTongTienHang(tienHangGoc);
        response.setSoTienGiam(soTienGiam);
        response.setMaGiamGiaApDung(maGiamGiaApDung != null ? maGiamGiaApDung.getMaCode() : null);
        response.setTongTien(totalAmount);
        response.setSoTienPhuThu(soTienPhuThu);

        // Đã sửa: Trích xuất chuỗi String từ Enum để map với DTO
        response.setTrangThai(savedDonHang.getTrangThai().name());

        response.setNguonDon(savedDonHang.getNguonDon());
        response.setVietQrUrl(vietQrUrl);
        response.setReceiptText(receiptText);

        return response;
    }

    @Transactional
    public void confirmPosOrderPaid(Long donHangId, String emailNhanVien) {
        DonHang donHang = donHangRepository.findById(donHangId)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy hóa đơn POS: " + donHangId));

        if (!"POS".equals(donHang.getNguonDon())) {
            throw new NgoaiLeNghiepVu("Đây không phải hóa đơn bán tại quầy, không thể xác nhận bằng chức năng này!");
        }

        if (donHang.getTrangThai() != TrangThaiDonHang.DA_XAC_NHAN) {
            throw new NgoaiLeNghiepVu("Hóa đơn không ở trạng thái chờ thanh toán QR!");
        }

        // Mua tại quầy: khách đã quét QR + nhận hàng trực tiếp -> hoàn tất luôn, không qua sản xuất/giao hàng
        donHang.setTrangThai(TrangThaiDonHang.HOAN_THANH);
        donHangRepository.save(donHang);
    }

    @Transactional
    public void cancelPosOrder(Long donHangId, String emailNhanVien) {
        DonHang donHang = donHangRepository.findById(donHangId)
                .orElseThrow(() -> new NgoaiLeKhongTimThayTaiNguyen("Không tìm thấy hóa đơn POS: " + donHangId));

        if (!"POS".equals(donHang.getNguonDon())) {
            throw new NgoaiLeNghiepVu("Đây không phải hóa đơn bán tại quầy, không thể hủy bằng chức năng này!");
        }

        // Chỉ cho hủy khi đơn còn đang chờ khách quét QR thanh toán (chưa hoàn tất giao dịch)
        if (donHang.getTrangThai() != TrangThaiDonHang.DA_XAC_NHAN) {
            throw new NgoaiLeNghiepVu("Hóa đơn đã được xử lý tiếp theo, không thể hủy vào lúc này!");
        }

        // Hoàn lại tồn kho đã trừ lúc tạo đơn
        for (ChiTietDonHang chiTiet : donHang.getChiTietDonHangs()) {
            sanPhamRepository.congLaiSoLuongTon(chiTiet.getSanPham().getId(), chiTiet.getSoLuong());
        }

        donHang.setTrangThai(TrangThaiDonHang.DA_HUY);
        donHang.setLyDoHuy("Nhân viên hủy mã QR trước khi khách thanh toán (Hóa đơn quầy)");
        donHangRepository.save(donHang);
    }

    // Hàm phụ định dạng văn bản in hóa đơn cân đối
    private String buildReceiptTemplate(DonHang donHang, String itemsText, String tenNhanVien,
                                         BigDecimal soTienGiam, MaGiamGia maGiamGiaApDung) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String dongGiamGia = (maGiamGiaApDung != null && soTienGiam.compareTo(BigDecimal.ZERO) > 0)
                ? "Mã giảm giá (" + maGiamGiaApDung.getMaCode() + "): -" + soTienGiam + " VND\n"
                : "";
        return "======= TIỆM BÁNH POLY CAKE =======" + "\n" +
                "Đ/C: Toà nhà FPT Polytechnic, HCM" + "\n" +
                "HÓA ĐƠN BÁN HÀNG TẠI QUẦY" + "\n" +
                "-----------------------------------" + "\n" +
                "Mã HD: HD-POS-" + donHang.getId() + "\n" +
                "Ngày: " + LocalDateTime.now().format(formatter) + "\n" +
                "Thu ngân: " + tenNhanVien + "\n" +
                "-----------------------------------" + "\n" +
                itemsText +
                dongGiamGia +
                "-----------------------------------" + "\n" +
                "TỔNG TIỀN: " + donHang.getTongTien().toString() + " VND\n" +
                "===================================" + "\n" +
                "  CẢM ƠN QUÝ KHÁCH - HẸN GẶP LẠI!  " + "\n";
    }

    // ── Kiểm tra & tính mã giảm giá công khai (giống logic ở DatHangService, dùng lại cho POS) ──

    private void kiemTraMaGiamGiaHopLe(MaGiamGia maGiamGia, BigDecimal tongTienHang) {
        if (!Boolean.TRUE.equals(maGiamGia.getHoatDong())) {
            throw new NgoaiLeNghiepVu("Mã giảm giá \"" + maGiamGia.getMaCode() + "\" hiện không còn hoạt động!");
        }
        if (maGiamGia.getNgayHetHan() != null && maGiamGia.getNgayHetHan().isBefore(LocalDateTime.now())) {
            throw new NgoaiLeNghiepVu("Mã giảm giá \"" + maGiamGia.getMaCode() + "\" đã hết hạn!");
        }
        if (maGiamGia.getSoLuotToiDa() != null
                && maGiamGia.getSoLuotDaDung() != null
                && maGiamGia.getSoLuotDaDung() >= maGiamGia.getSoLuotToiDa()) {
            throw new NgoaiLeNghiepVu("Mã giảm giá \"" + maGiamGia.getMaCode() + "\" đã hết lượt sử dụng!");
        }
        if (maGiamGia.getDonHangToiThieu() != null
                && tongTienHang.compareTo(maGiamGia.getDonHangToiThieu()) < 0) {
            throw new NgoaiLeNghiepVu(
                    "Hoá đơn cần tối thiểu " + maGiamGia.getDonHangToiThieu()
                            + " để áp dụng mã \"" + maGiamGia.getMaCode() + "\"!");
        }
    }

    private BigDecimal tinhSoTienGiam(MaGiamGia maGiamGia, BigDecimal tongTienHang) {
        BigDecimal soTienGiam;
        if ("PHAN_TRAM".equals(maGiamGia.getLoaiGiamGia())) {
            soTienGiam = tongTienHang.multiply(maGiamGia.getGiaTriGiam())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        } else {
            soTienGiam = maGiamGia.getGiaTriGiam();
        }
        return soTienGiam.min(tongTienHang);
    }
}