-- ═══════════════════════════════════════════════════════════════════════════
-- Đặt tên CỐ ĐỊNH cho ràng buộc UNIQUE trên cột email (thay vì để Hibernate
-- tự đặt tên ngẫu nhiên kiểu "UQ__nguoi_du__AB6E61645E2F1A01"), để code Java
-- (AuthService.register) có thể nhận diện CHẮC CHẮN đây là lỗi trùng email
-- khi bắt DataIntegrityViolationException, mà KHÔNG cần query lại DB (query
-- lại trong cùng transaction đã lỗi sẽ làm Hibernate Session bị "nhiễm độc"
-- và ném AssertionFailure "null id ... don't flush the Session after an
-- exception occurs").
--
-- CÁCH CHẠY: mở file này trong SSMS, chọn đúng database rồi Execute.
-- Chạy lại nhiều lần vẫn an toàn (không tạo thêm lỗi).
-- ═══════════════════════════════════════════════════════════════════════════

-- B1. Tìm và xoá UNIQUE constraint/index hiện có trên (đúng) cột email,
--     bất kể tên do Hibernate tự sinh là gì
DECLARE @indexName NVARCHAR(255);
DECLARE idx_cursor CURSOR FOR
    SELECT i.name
    FROM sys.indexes i
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
    WHERE i.object_id = OBJECT_ID('nguoi_dung')
      AND i.is_unique = 1
      AND i.name IS NOT NULL
      AND i.name <> 'UQ_nguoi_dung_email'
      AND c.name = 'email'
      AND (SELECT COUNT(*) FROM sys.index_columns ic2 WHERE ic2.object_id = i.object_id AND ic2.index_id = i.index_id) = 1;

OPEN idx_cursor;
FETCH NEXT FROM idx_cursor INTO @indexName;
WHILE @@FETCH_STATUS = 0
BEGIN
    -- Có thể là UNIQUE CONSTRAINT (key_constraints) hoặc UNIQUE INDEX thường
    IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = @indexName AND parent_object_id = OBJECT_ID('nguoi_dung'))
        EXEC('ALTER TABLE nguoi_dung DROP CONSTRAINT [' + @indexName + ']');
    ELSE
        EXEC('DROP INDEX [' + @indexName + '] ON nguoi_dung');

    FETCH NEXT FROM idx_cursor INTO @indexName;
END
CLOSE idx_cursor;
DEALLOCATE idx_cursor;
GO

-- B2. Tạo lại UNIQUE CONSTRAINT với tên cố định
IF NOT EXISTS (
    SELECT 1 FROM sys.key_constraints
    WHERE name = 'UQ_nguoi_dung_email' AND parent_object_id = OBJECT_ID('nguoi_dung')
)
BEGIN
    ALTER TABLE nguoi_dung ADD CONSTRAINT UQ_nguoi_dung_email UNIQUE (email);
END
GO
