-- ═══════════════════════════════════════════════════════════════════════════
-- FIX BUG: Đăng ký tài khoản thường bị lỗi 500 / báo "Dữ liệu bị trùng"
-- dù email & số điện thoại hoàn toàn mới.
--
-- NGUYÊN NHÂN: cột google_id được tạo với UNIQUE CONSTRAINT thông thường
-- (do JPA entity khai báo unique=true + hibernate.ddl-auto=update, hoặc do
-- script 003_add_google_id_and_phone_unique.sql). Trên SQL Server, UNIQUE
-- CONSTRAINT thông thường CHỈ cho phép ĐÚNG 1 dòng có giá trị NULL trong cột
-- (coi mọi NULL là bằng nhau) — khác hẳn MySQL/PostgreSQL (cho phép nhiều NULL).
--
-- Vì tài khoản đăng ký thường (không qua Google) luôn có google_id = NULL,
-- nên NGAY SAU tài khoản thường đầu tiên, mọi tài khoản thường tiếp theo đều
-- vi phạm UNIQUE constraint này khi INSERT -> DataIntegrityViolationException.
--
-- CÁCH SỬA: xoá UNIQUE constraint/index hiện có trên google_id, thay bằng
-- FILTERED UNIQUE INDEX chỉ áp dụng cho các dòng CÓ giá trị (IS NOT NULL).
-- Nhờ vậy vẫn đảm bảo 1 tài khoản Google chỉ gắn với đúng 1 user, nhưng
-- không giới hạn số lượng tài khoản có google_id = NULL.
--
-- CÁCH CHẠY: mở file này trong SSMS, chọn đúng database rồi Execute.
-- Chạy lại nhiều lần vẫn an toàn (không tạo thêm lỗi).
-- ═══════════════════════════════════════════════════════════════════════════

-- B1. Xoá UNIQUE CONSTRAINT trên google_id nếu có (tên do script 003 tạo)
IF EXISTS (
    SELECT 1 FROM sys.key_constraints
    WHERE name = 'UQ_nguoi_dung_google_id' AND parent_object_id = OBJECT_ID('nguoi_dung')
)
BEGIN
    ALTER TABLE nguoi_dung DROP CONSTRAINT UQ_nguoi_dung_google_id;
END
GO

-- B2. Xoá mọi UNIQUE INDEX khác trên đúng 1 cột google_id do Hibernate
--     tự sinh ra (ddl-auto=update thường đặt tên dạng UK_xxxxxxxxxxxxxxxx)
DECLARE @indexName NVARCHAR(255);
DECLARE idx_cursor CURSOR FOR
    SELECT i.name
    FROM sys.indexes i
    JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
    WHERE i.object_id = OBJECT_ID('nguoi_dung')
      AND i.is_unique = 1
      AND i.name IS NOT NULL
      AND i.name <> 'UQ_nguoi_dung_google_id_filtered'
      AND c.name = 'google_id'
      -- chỉ lấy index có ĐÚNG 1 cột (google_id), tránh đụng index nhiều cột khác
      AND (SELECT COUNT(*) FROM sys.index_columns ic2 WHERE ic2.object_id = i.object_id AND ic2.index_id = i.index_id) = 1;

OPEN idx_cursor;
FETCH NEXT FROM idx_cursor INTO @indexName;
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC('DROP INDEX [' + @indexName + '] ON nguoi_dung');
    FETCH NEXT FROM idx_cursor INTO @indexName;
END
CLOSE idx_cursor;
DEALLOCATE idx_cursor;
GO

-- B3. Tạo lại UNIQUE INDEX đúng chuẩn: chỉ áp dụng cho các dòng CÓ liên kết
--     Google (google_id IS NOT NULL) -> cho phép nhiều dòng NULL cùng lúc
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'UQ_nguoi_dung_google_id_filtered' AND object_id = OBJECT_ID('nguoi_dung')
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX UQ_nguoi_dung_google_id_filtered
        ON nguoi_dung(google_id)
        WHERE google_id IS NOT NULL;
END
GO